#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <math.h>

// constants
#define MAX_LIST 5000       // max words in toxic dict
#define MAX_STOP 1000       // max stop words
#define MAX_VOCAB 10000     // NEW: max unique words to track
#define BUF_SIZE 100        // buffer size

// struct for toxic words
typedef struct {
    char text[BUF_SIZE];
    char type[BUF_SIZE];
    int sev;    
    int found;  
} Term;

// NEW: struct for general vocabulary stats
typedef struct {
    char word[BUF_SIZE];
    int count;
} Vocab;

// global arrays
Term list[MAX_LIST];
int list_len = 0;

char skip_list[MAX_STOP][BUF_SIZE];
int skip_len = 0;

Vocab vocabulary[MAX_VOCAB]; // NEW: Track all unique words
int vocab_len = 0;

// helper to fix leet speak
char fix_leet(char c) {
    c = tolower(c);
    if (c == '0') return 'o';
    if (c == '1') return 'i';
    if (c == '3') return 'e';
    if (c == '4') return 'a';
    if (c == '5') return 's';
    if (c == '7') return 't';
    if (c == '@') return 'a';
    if (c == '$') return 's';
    return c;
}

// cleans up string
void clean(char *in, char *out) {
    int i, j = 0;
    int len = strlen(in);
    char c, fixed;

    for (i = 0; i < len; i++) {
        c = in[i];
        if (c < 32) continue;
        if (isalpha(c)) {
            out[j++] = tolower(c);
        } else {
            fixed = fix_leet(c);
            if (isalpha(fixed)) {
                out[j++] = fixed;
            }
        }
        if (j >= BUF_SIZE - 1) break;
    }
    out[j] = '\0';

    // check for triple letters
    if (j > 2) {
        char temp[BUF_SIZE];
        int k = 0, x;
        int rep = 1;
        temp[0] = out[0];
        for (x = 1; x < j; x++) {
            if (out[x] == out[x-1]) rep++;
            else rep = 1;
            if (rep <= 2) temp[++k] = out[x];
        }
        temp[++k] = '\0';
        strcpy(out, temp);
    }
}

// load stopwords
void load_skip_words() {
    FILE *fp = fopen("stopwords.txt", "r");
    char buffer[BUF_SIZE];
    if (fp == NULL) {
        printf("Note: stopwords.txt missing. Stopword filtering disabled.\n");
        return;
    }
    while (fscanf(fp, "%s", buffer) == 1) {
        if (skip_len >= MAX_STOP) break;
        clean(buffer, skip_list[skip_len]);
        skip_len++;
    }
    fclose(fp);
}

// check stop list
int should_skip(char *w) {
    for (int i = 0; i < skip_len; i++) {
        if (strcmp(w, skip_list[i]) == 0) return 1;
    }
    return 0;
}

// load dictionary
void load_dict() {
    FILE *fp = fopen("toxic_dictionary.txt", "r");
    char line[512], *p1, *p2, *p3;
    if (fp == NULL) {
        printf("Error: toxic_dictionary.txt not found.\n");
        return;
    }
    printf("Loading data...\n");
    while (fgets(line, sizeof(line), fp)) {
        if (list_len >= MAX_LIST) break;
        line[strcspn(line, "\r\n")] = 0;
        if (strlen(line) < 2) continue;
        if (strchr(line, '|')) {
            p1 = strtok(line, "|");
            p2 = strtok(NULL, "|");
            p3 = strtok(NULL, "|");
            if (p1 && p2 && p3) {
                clean(p1, list[list_len].text);
                strcpy(list[list_len].type, p2);
                list[list_len].sev = atoi(p3);
                list[list_len].found = 0;
                list_len++;
            }
        }
    }
    fclose(fp);
    printf("Loaded %d toxic terms.\n", list_len);
}

// compare function for toxic terms
int cmp_toxic(const void *a, const void *b) {
    Term *xA = (Term *)a;
    Term *xB = (Term *)b;
    return (xB->found - xA->found);
}

// NEW: compare function for general vocab
int cmp_vocab(const void *a, const void *b) {
    Vocab *xA = (Vocab *)a;
    Vocab *xB = (Vocab *)b;
    return (xB->count - xA->count);
}

// NEW: Add word to general vocabulary
void add_to_vocab(char *word) {
    // Linear search (simple but effective for this assignment)
    for (int i = 0; i < vocab_len; i++) {
        if (strcmp(vocabulary[i].word, word) == 0) {
            vocabulary[i].count++;
            return;
        }
    }
    // New unique word
    if (vocab_len < MAX_VOCAB) {
        strcpy(vocabulary[vocab_len].word, word);
        vocabulary[vocab_len].count = 1;
        vocab_len++;
    }
}

void scan_file(char *fname) {
    FILE *fp = fopen(fname, "r");
    int i, matched;
    char raw[256], curr[BUF_SIZE];
    int sentence_count = 0, word_cnt = 0;
    
    // reset stats
    vocab_len = 0; 
    for(i = 0; i < list_len; i++) list[i].found = 0;

    // sliding window
    char win[3][BUF_SIZE] = {"", "", ""};

    if (fp == NULL) {
        printf("Error: Can't open %s.\n", fname);
        return;
    }

    printf("\nScanning file: %s ...\n", fname);

    while (fscanf(fp, "%255s", raw) == 1) {
        int rlen = strlen(raw);
        if (raw[rlen-1] == '.' || raw[rlen-1] == '!' || raw[rlen-1] == '?') {
            sentence_count++;
        }

        clean(raw, curr);
        if (strlen(curr) == 0) continue;

        word_cnt++;
        
        // NEW: Add to unique vocabulary tracker
        add_to_vocab(curr);

        // Update sliding window
        strcpy(win[0], win[1]);
        strcpy(win[1], win[2]);
        strcpy(win[2], curr);

        matched = 0;

        // 1. Check 3-word phrases
        if (strlen(win[0]) > 0) {
            char phrase[300];
            snprintf(phrase, sizeof(phrase), "%s %s %s", win[0], win[1], win[2]);
            for(i = 0; i < list_len; i++) {
                if (strcmp(phrase, list[i].text) == 0) {
                    list[i].found++;
                    matched = 1;
                    strcpy(win[0], ""); strcpy(win[1], ""); // consume
                    break;
                }
            }
        }

        // 2. Check 2-word phrases
        if (!matched && strlen(win[1]) > 0) {
            char phrase[200];
            snprintf(phrase, sizeof(phrase), "%s %s", win[1], win[2]);
            for(i = 0; i < list_len; i++) {
                if (strcmp(phrase, list[i].text) == 0) {
                    list[i].found++;
                    matched = 1;
                    strcpy(win[1], ""); // consume
                    break;
                }
            }
        }

        // 3. Check single word (if not stopword)
        if (!matched) {
            if (!should_skip(curr)) {
                for(i = 0; i < list_len; i++) {
                    if (strcmp(curr, list[i].text) == 0) {
                        list[i].found++;
                        break;
                    }
                }
            }
        }
    }
    fclose(fp);

    // Calc Stats
    long score_sum = 0;
    int hits_total = 0;
    
    // Sort Toxic List
    Term *sorted_res = (Term *)malloc(sizeof(Term) * list_len);
    if (sorted_res) {
        memcpy(sorted_res, list, sizeof(Term) * list_len);
        for(i = 0; i < list_len; i++) {
            if (sorted_res[i].found > 0) {
                hits_total += sorted_res[i].found;
                score_sum += (sorted_res[i].found * sorted_res[i].sev * sorted_res[i].sev);
            }
        }
        qsort(sorted_res, list_len, sizeof(Term), cmp_toxic);
    }

    // Sort General Vocabulary
    qsort(vocabulary, vocab_len, sizeof(Vocab), cmp_vocab);

    float ratio = (word_cnt > 0) ? (float)score_sum * 100.0 / word_cnt : 0;
    if (sentence_count == 0) sentence_count = 1;
    float avg_len = (float)word_cnt / sentence_count;
    float lexical_diversity = (word_cnt > 0) ? (float)vocab_len / word_cnt : 0; // NEW metric

    // --- DISPLAY ---
    printf("\n--- ANALYSIS RESULTS: %s ---\n", fname);
    printf("Total Words:      %d\n", word_cnt);
    printf("Unique Words:     %d\n", vocab_len); // NEW
    printf("Lexical Density:  %.2f\n", lexical_diversity); // NEW
    printf("Sentences:        %d\n", sentence_count);
    printf("Avg Sen Length:   %.2f words\n", avg_len);
    printf("Toxic Words:      %d\n", hits_total);
    printf("Toxicity Score:   %.2f\n", ratio);
    
    if (ratio < 10) printf("Status: SAFE\n");
    else if (ratio < 30) printf("Status: WARNING\n");
    else printf("Status: TOXIC\n");

    printf("\n--- Most Frequent Words (Top 5) ---\n"); // NEW Section
    for(i=0; i<5 && i<vocab_len; i++) {
        printf("%d. %-15s (%d)\n", i+1, vocabulary[i].word, vocabulary[i].count);
    }

    printf("\n--- Toxic Hits (Top 5) ---\n");
    int count = 0;
    for(i = 0; i < list_len; i++) {
        if (sorted_res && sorted_res[i].found > 0) {
            printf("%d. %-15s (Count: %d)\n", count+1, sorted_res[i].text, sorted_res[i].found);
            count++;
            if (count >= 5) break;
        }
    }
    
    // Save Report
    FILE *out = fopen("report.txt", "w");
    if (out) {
        fprintf(out, "File: %s\nScore: %.2f\nHits: %d\n", fname, ratio, hits_total);
        fprintf(out, "Stats: %d words, %d unique, %d sentences\n\n", word_cnt, vocab_len, sentence_count);
        fprintf(out, "--- Top Frequent Words ---\n");
        for(i=0; i<10 && i<vocab_len; i++) fprintf(out, "%s: %d\n", vocabulary[i].word, vocabulary[i].count);
        fprintf(out, "\n--- Toxic Hits ---\n");
        for(i = 0; i < list_len; i++) {
            if (sorted_res && sorted_res[i].found > 0) {
                fprintf(out, "%s | %d | Sev: %d\n", sorted_res[i].text, sorted_res[i].found, sorted_res[i].sev);
            }
        }
        fclose(out);
        printf("\nSaved full details to report.txt\n");
    }

    if(sorted_res) free(sorted_res);
}

int main() {
    char name[100] = {0};
    int choice = 0;
    
    printf("Initializing System...\n");
    load_skip_words();
    load_dict();

    while(1) {
        printf("\n=============================\n");
        printf("   TOXIC WORDS DETECTOR    \n");
        printf("=============================\n");
        printf("1. Load Input File\n");
        printf("2. Start Analysis\n");
        printf("3. Exit\n");
        printf("Select option: ");
        fflush(stdout);
        
        if (scanf("%d", &choice) != 1) {
            while(getchar() != '\n'); // clear bad input
            continue;
        }
        while(getchar() != '\n'); 

        switch(choice) {
            case 1:
                printf("Enter filename: ");
                scanf("%99s", name);
                while(getchar() != '\n'); 
                printf("File set to: %s\n", name);
                break;
            case 2:
                if (strlen(name) == 0) printf("Error: Load file first.\n");
                else scan_file(name);
                break;
            case 3:
                printf("Exiting...\n");
                return 0;
            default:
                printf("Invalid choice.\n");
        }
    }
    return 0;
}